#include <Mob.h>
#include <Tablet.h>
#include <Laptop.h>
#include <Client.h>

int main(){
    Client *ptr = new Client(1);
    Lenovo* ptr1 = ptr->getDevice();
    ptr1->prodDescr();

    // Lenovo* ptr1 = Lenovo::create_product(1);    
    // ptr1->prodDescr();

    // Lenovo* ptr2 = Laptop::create_product(2);
    // ptr2->prodDescr();

    // Lenovo* ptr3 = Tab::create_product(3);
    // ptr3->prodDescr();
    
    return 0;
}