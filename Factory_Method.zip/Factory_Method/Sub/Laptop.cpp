#include <Laptop.h>

void Laptop::prodDescr(){
    cout<<"I'm Lenovo Laptopile";
    cout<<"Laptop_name: "<<prod_name<<" id: "<<prod_id;
    cout<<endl;
}

Laptop::Laptop(string name, string id){
    prod_name = (name);
    prod_id = (id);
}