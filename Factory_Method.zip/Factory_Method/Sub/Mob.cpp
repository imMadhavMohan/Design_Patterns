#include <Mob.h>

void Mob::prodDescr(){
    cout<<"I'm Lenovo mobile";
    cout<<"Mob_name: "<<prod_name<<" id: "<<prod_id;
    cout<<endl;
}

Mob::Mob(string name, string id){
    prod_name = (name);
    prod_id = (id);
}