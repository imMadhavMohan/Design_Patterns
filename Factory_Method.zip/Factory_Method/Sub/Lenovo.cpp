#include <Lenovo.h>
#include <Mob.h>
#include <Tablet.h>
#include <Laptop.h>

Lenovo* Lenovo::create_product(int choice){
    if(choice==1){
        return new Mob("Lenovo-Z","Len-Z2");    
    }
    else if(choice==2){
        return new Laptop("thinkPad", "Thnk-1999");
    }
    else if(choice==3){
        return new Tab("Yoga-S","YS-9");
    }
    return nullptr;
}
