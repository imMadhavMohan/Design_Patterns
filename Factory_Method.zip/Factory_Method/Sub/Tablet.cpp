#include <Tablet.h>

void Tab::prodDescr(){
    cout<<"I'm Lenovo Tablet";
    cout<<"Mob_name: "<<prod_name<<" id: "<<prod_id;
    cout<<endl;
}

Tab::Tab(string name, string id){
    prod_name = (name);
    prod_id = (id);
}