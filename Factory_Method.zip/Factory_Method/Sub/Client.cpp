#include <Client.h>

Client::Client(int choice){
    device = Lenovo::create_product(choice);
}

Lenovo* Client::getDevice(){
    return device;
}