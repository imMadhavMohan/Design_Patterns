#ifndef factry_h
#define factry_h

#include <string>
#include <iostream>
using namespace std;

class Lenovo{
    protected:
        string prod_name;
        string prod_id;

    public:
        virtual void prodDescr() = 0; // product description
        static Lenovo* create_product(int choice);        
};

#endif