#ifndef client_h
#define client_h

#include <Lenovo.h>

class Client{    
    public:
        Client(int choice);
        ~Client(){}
        Lenovo* getDevice();

    private:
        Lenovo* device;
};

#endif