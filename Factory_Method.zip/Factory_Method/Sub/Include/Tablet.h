#ifndef tab_h
#define tab_h

#include <Lenovo.h>

class Tab: public Lenovo{    
    public:
        void prodDescr();
        Tab(string name, string id);                
};

#endif