#ifndef laptop_h
#define laptop_h

#include <Lenovo.h>

class Laptop: public Lenovo{    
    public:
        void prodDescr();
        Laptop(string name, string id);       
};

#endif