#ifndef mob_h
#define mob_h

#include <Lenovo.h>


class Mob: public Lenovo{    
    public:
        void prodDescr();
        Mob(string name, string id);                
};

#endif