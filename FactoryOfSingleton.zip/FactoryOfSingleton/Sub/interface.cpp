#include <interface.h>

Factory *interface::createDb(Type type)
{
    if (type == MySql)
    {
        MySQl *ptr = MySQl::getInstance();
        return ptr;
    }
    else if (type == MongoDb)
    {
        MongoDB *ptr = MongoDB::getInstance();
        return ptr;
    }
    return nullptr;
}

interface::interface(){}