#include <dbTwo.h>

MongoDB *MongoDB::instance = nullptr;

MongoDB *MongoDB::getInstance()
{
    if (!instance)
    { // can also check by ptr
        instance = new MongoDB();
        return instance;
    }
    return instance;
}

void MongoDB::DBConnect()
{
    check += 1;
    cout << "Current Instances of MongoDB: " << check << endl;
}

MongoDB::MongoDB() {}

MongoDB::MongoDB(const MongoDB &)
{
    cout << "Copy Constructor of MongoDB\n";
}

void MongoDB::operator=(const MongoDB &)
{
    cout << "I'm private assignment operator\n";
}

MongoDB::~MongoDB()
{
    instance = nullptr;
}
