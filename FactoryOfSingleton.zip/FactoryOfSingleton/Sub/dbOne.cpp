#include<dbOne.h>

MySQl* MySQl::instance = nullptr;

MySQl* MySQl::getInstance(){
    if(!instance){ // can also check by ptr
       instance = new MySQl();
       return instance;
    }
    return instance;
}

void MySQl::DBConnect(){
    check += 1;
    cout<<"Current Instances of MySQl: "<<check<<endl;
}

MySQl::~MySQl(){
    instance = nullptr;
}

MySQl::MySQl(const MySQl &){
    cout<<"Copy Constructor of MySQl\n";
}

MySQl::MySQl(){

}

void MySQl::operator = (const MySQl &){
    cout<<"I'm private assignment operator\n";
}