#ifndef interf_h
#define interf_h

#include <Factory.h>
#include <dbOne.h>
#include <dbTwo.h>

class interface
{
protected:
      string userName;
      string userId;

public:
      interface();
      static Factory *createDb(Type);
      static void getDbinfo();
};

#endif