#ifndef fact_h
#define fact_h

enum Type
{
    MySql,
    MongoDb
};

#include <iostream>
#include <string>
using namespace std;

class Factory
{
    public:
        virtual void DBConnect() = 0;
};

#endif