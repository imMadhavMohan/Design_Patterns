#ifndef dbtwo_h
#define dbtwo_h

#include <Factory.h>

class MongoDB: public Factory{
    private:    
        static MongoDB *instance;
        int check = 0;
        MongoDB();

        MongoDB(const MongoDB &); // copy constructor

        void operator = (const MongoDB &); // overloading assignmentoperator            

    public:
        static MongoDB* getInstance();
        void DBConnect();
        ~MongoDB();
};


#endif
