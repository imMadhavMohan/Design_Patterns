#ifndef dbone_h
#define dbone_h

#include <Factory.h>

class MySQl: public Factory{
    private:
        static bool isObjCreated;
        static MySQl *instance;
        int check = 0;
        MySQl();

        MySQl(const MySQl &); // copy constructor

        void operator = (const MySQl &); // overloading assignmentoperator            

    public:
        static MySQl* getInstance();

        void DBConnect();

        ~MySQl();
};


#endif

