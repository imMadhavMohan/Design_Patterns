#include <interface.h>

int main(){
    // 1st case
    Factory* ptr1 = interface::createDb(MySql);
    ptr1->DBConnect(); // print -> 1

    Factory* ptr2 = interface::createDb(MySql);
    ptr1->DBConnect(); // print -> 2 
    
    // means new obj hasn't created

    // 2nd case
    cout<<endl;

    Factory* ptr3 = interface::createDb(MongoDb);
    ptr3->DBConnect();  // print -> 1
    
    Factory* ptr4 = interface::createDb(MongoDb);
    ptr4->DBConnect();  // print -> 2 
    
    // means new obj hasn't created

    return 0;
}

