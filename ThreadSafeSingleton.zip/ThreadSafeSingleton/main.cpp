#include "iostream"
#include "Sub/Include/interface.h"
#include "mutex"

using namespace std;

int main(){
    Singleton *ptr = ptr->getInstance();
    ptr->setData(10);    
    cout<<ptr->getData();
    
    cout<<'\n';

    Singleton *ptr1 = ptr1->getInstance();
    ptr1->setData(11);    
    cout<<ptr1->getData();
   
    return 0;
}

