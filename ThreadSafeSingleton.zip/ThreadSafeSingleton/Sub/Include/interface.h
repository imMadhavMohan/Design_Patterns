#ifndef inerface_h
#define interface_h

#include "mutex"
using namespace std;

class Singleton
{
private:
    static Singleton *instance; // we have made it static as we're gonna use it inside the static method  

    int data;   

    static mutex mtx;

    Singleton(); // default contructor

    static int cnt; // count the instances
    
public:
    static Singleton *getInstance();
    int getData();
    void setData(int val);
};

#endif
