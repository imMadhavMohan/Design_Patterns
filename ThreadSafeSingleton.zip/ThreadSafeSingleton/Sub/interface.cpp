#include "iostream"
#include "Include/interface.h"

using namespace std;

Singleton *Singleton::instance = nullptr; 

mutex Singleton::mtx;

int Singleton::cnt = 0;

Singleton::Singleton(){
    cnt++;
    std::cout<<"Num of Instances "<<cnt<<endl;
}

Singleton* Singleton::getInstance() 
{ 
    if (!instance) // Double Lock Technique of check
    {
        mtx.lock();
        if (!instance)
        {
          instance = new Singleton(); 
        } 
        mtx.unlock();
    }               
    return instance;
}

int Singleton::getData()
{
    return this->data;
}
void Singleton::setData(int val)
{
    this->data = val;
}

