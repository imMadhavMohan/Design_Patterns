#include <Singleton.h>
#include <Octal.h>
#include <decimal.h>

string Number::type = "";

Number *Number::inst = nullptr;

void Number::setType(string t){ 
    type = t;
    delete inst;
    inst = 0;
}

Number *Number::instance() // str
{
  if (!inst)    
    if (type == "octal")
      inst = new Octal();
    else if (type == "deci")
      inst = new Decimal();
    else return nullptr;

  return inst;
}

Number::Number(){}

void Number::getType(){
    cout<<type;
}

auto value = -1;

// vTabe error we get when we declare a function as non-pure virtual but virtual so 
// we need to just give it a implementation in the parent class

//  virtual void hello() = default;
//  or make any one of the virtual fun as pure virtual;
// or give any implementation