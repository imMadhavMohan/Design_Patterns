#ifndef deci_h
#define deci_h

#include <Singleton.h>

class Decimal: public Number
{  
  public:    
    void setValue(int in);
    int getValue(); // 1

    Decimal(){}    
};

#endif
