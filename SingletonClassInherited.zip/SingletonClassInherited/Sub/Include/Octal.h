#ifndef oct_h
#define oct_h

#include <Singleton.h>

class Octal: public Number
{  
  public:
    void setValue(int in);
    int getValue(); // 1
  
    Octal(){}
};

#endif
