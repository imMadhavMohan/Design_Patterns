#ifndef singl_h
#define singl_h

#include <cstring>
#include <iostream>
using namespace std;

class Number
{
  // 2. Define a public static accessor func
  public:    
    static Number *instance(); // type
    static void setType(string t) ;

    virtual void setValue(int in) = 0;
    virtual int getValue() = 0 ;       
    static void getType();

  protected:
    int value; // octal & int    
    
    Number();
  // 1. Define a private static attribute
  private:
    static string type;
    static Number *inst; 
};

#endif

// vTabe error we get when we declare a function as non-pure virtual but virtual so 
// we need to just give it a implementation in the parent class

//  virtual void hello() = default;
//  or make any one of the virtual fun as pure virtual;
// or give any implementation
