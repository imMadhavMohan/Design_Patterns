#include <Octal.h>

void Octal::setValue(int in)
{  
  char buf[10];  
  sprintf(buf, "%o", in);
  sscanf(buf, "%d", &value);
}

int Octal::getValue(){
  return value;
}

