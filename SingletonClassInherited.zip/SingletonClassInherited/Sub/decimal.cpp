#include <decimal.h>

void Decimal::setValue(int in)
{
  char buf[10];  
  sprintf(buf, "%d", in);
  sscanf(buf,"%d",&value);    
}

int Decimal::getValue(){  
  return value;
}