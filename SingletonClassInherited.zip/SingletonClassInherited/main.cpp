#include <iostream>
#include <string>
#include <stdlib.h>

#include <common.h> 

int main()
{
  Number::setType("deci");
  Number::getType();
  cout<<endl;  
  cout<<"ptr1->: ";
  Number *ptr1 = Decimal::instance(); // Hexa obj
  
  ptr1->setValue(250);
  cout << ptr1->getValue();  

  cout<<endl<<endl;

  Octal::setType("octal");
  Octal::getType();
  cout<<endl;
  cout<<"ptr2->: ";
  Number* ptr2 = Octal::instance();

  ptr2->setValue(64);
  cout<<ptr2->getValue();
  cout<<endl;

  cout<<"\nCross Check ptr1-> val: ";
  cout<<ptr1->getValue();
  cout<<endl;
  return 0;  
}

// Inheritance can be supported Just by making Base class contructor as Protected & but static
// functions may not be overridden. The base -
// class must be declared a friend of the derived class (in order to access the protected
// constructor).