#include "iostream"
#include "Sub/Include/Singleton.h"

using namespace std;

int main(){
    // Singleton conn;
    Singleton *ptr1 = Singleton::create(12);
    cout<<"1st connection "<<ptr1->val<<'\n';
    cout<<"1nd ptr address "<<ptr1<<'\n';

    // Singleton conn1;
    Singleton *ptr2 = Singleton::create(10);
    cout<<"2nd connection "<<ptr2->val<<'\n';
    cout<<"2nd ptr address "<<ptr2<<'\n'; 
    
    // First conncection address again
    cout<<"2nd ptr address "<<ptr1->val<<'\n'; 

    return 0;   
}
