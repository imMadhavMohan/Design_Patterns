#include "iostream"
#include "Include/Singleton.h"

using namespace std;
Singleton* Singleton::instance = nullptr;

Singleton* Singleton::create(int val){
    if(!instance)        
	instance = new Singleton(val);
    return instance;
}

