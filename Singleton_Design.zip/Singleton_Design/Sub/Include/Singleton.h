#ifndef singleton_h
#define singleton_h

class Singleton{
    private:
        static Singleton* instance;        
    public:
        int val{0};
        Singleton(int val):val(val){};
        static Singleton* create(int val);
};

#endif
